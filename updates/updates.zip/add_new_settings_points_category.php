<?php

$sql = "SELECT COUNT(*) FROM settings WHERE setting_id = 13";
if ($res = $db->query($sql)) {
    if($res->fetchColumn() == 0){
        $statement = $db->prepare('INSERT INTO product_categories (category_name)  VALUES ("Redeemable Items")');
        $statement->execute();

        $lastId = $db->lastInsertId();

        $statement = $db->prepare('INSERT INTO settings (setting_id, setting_name, setting_value)  VALUES (13, "Points Category", ?)');
        $statement->execute(array($lastId));
    }
}


?>